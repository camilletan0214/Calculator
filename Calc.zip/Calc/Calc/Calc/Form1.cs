﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Calc
{
    public partial class Form1 : Form
    {
        double InitialValue;
        string Operation;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0" && textBox1.Text != null)
            {
                textBox1.Text = "1";
            }
            else
            {
                textBox1.Text = textBox1.Text + "1";
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0" && textBox1.Text != null)
            {
                textBox1.Text = "2";
            }
            else
            {
                textBox1.Text = textBox1.Text + "2";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0" && textBox1.Text != null)
            {
                textBox1.Text = "3";
            }
            else
            {
                textBox1.Text = textBox1.Text + "3";
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0" && textBox1.Text != null)
            {
                textBox1.Text = "4";
            }
            else
            {
                textBox1.Text = textBox1.Text + "4";
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0" && textBox1.Text != null)
            {
                textBox1.Text = "5";
            }
            else
            {
                textBox1.Text = textBox1.Text + "5";
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0" && textBox1.Text != null)
            {
                textBox1.Text = "6";
            }
            else
            {
                textBox1.Text = textBox1.Text + "6";
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0" && textBox1.Text != null)
            {
                textBox1.Text = "7";
            }
            else
            {
                textBox1.Text = textBox1.Text + "7";
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0" && textBox1.Text != null)
            {
                textBox1.Text = "8";
            }
            else
            {
                textBox1.Text = textBox1.Text + "8";
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0" && textBox1.Text != null)
            {
                textBox1.Text = "9";
            }
            else
            {
                textBox1.Text = textBox1.Text + "9";
            }
        }

        private void button0_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "0";
        }

        private void add_Click(object sender, EventArgs e)
        {
            InitialValue = Convert.ToDouble(textBox1.Text);
            textBox1.Text = "0";
            Operation = "+";
        }

        private void substract_Click(object sender, EventArgs e)
        {
            InitialValue = Convert.ToDouble(textBox1.Text);
            textBox1.Text = "0";
            Operation = "-";
        }

        private void multiply_Click(object sender, EventArgs e)
        {
            InitialValue = Convert.ToDouble(textBox1.Text);
            textBox1.Text = "0";
            Operation = "X";
        }

        private void divide_Click(object sender, EventArgs e)
        {
            InitialValue = Convert.ToDouble(textBox1.Text);
            textBox1.Text = "0";
            Operation = "/";
        }

        private void module_Click(object sender, EventArgs e)
        {
            InitialValue = Convert.ToDouble(textBox1.Text);
            textBox1.Text = "0";
            Operation = "%";
        }

        private void clear_Click(object sender, EventArgs e)
        {
            textBox1.Text = "0";
        }

        private void dotbutton_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + ".";
        }

        private void total_Click(object sender, EventArgs e)
        {
            double AdditionalValue;
            double Result;
            AdditionalValue = Convert.ToDouble(textBox1.Text);

            if (Operation == "+")
            {
                Result = (InitialValue + AdditionalValue);
                textBox1.Text = Convert.ToString(Result);
                InitialValue = Result;
            }
            if (Operation == "-")
            {
                Result = (InitialValue - AdditionalValue);
                textBox1.Text = Convert.ToString(Result);
                InitialValue = Result;
            }
            if (Operation == "X")
            {
                Result = (InitialValue * AdditionalValue);
                textBox1.Text = Convert.ToString(Result);
                InitialValue = Result;
            }
            if (Operation == "/")
            {
                if (AdditionalValue == 0)
                {
                    textBox1.Text = "Invalid, cannot divide by zero";
                }
                Result = (InitialValue / AdditionalValue);
                textBox1.Text = Convert.ToString(Result);
                InitialValue = Result;
            }
            if (Operation == "%")
            {
                Result = (InitialValue % AdditionalValue);
                textBox1.Text = Convert.ToString(Result);
                InitialValue = Result;
            }
        }


    }
}
